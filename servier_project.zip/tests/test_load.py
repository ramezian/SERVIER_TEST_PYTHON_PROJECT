import unittest
import os
import json
from data_pipeline.load import save_json

class TestLoad(unittest.TestCase):
    def test_save_json(self):
        # Données de test pour le JSON
        data = {
            'Aspirin': [
                {"source": "pubmed", "publication_name": "Pain Relief Journal", "title": "Aspirin in pain relief", "date": "01/01/2023"}
            ]
        }
        output_file = 'output/test_results.json'

        # Sauvegarde des données dans un fichier JSON
        save_json(data, output_file)
        
        # Vérification que le fichier existe
        self.assertTrue(os.path.exists(output_file))
        
        # Chargement et vérification des données
        with open(output_file, 'r', encoding='utf-8') as f:
            saved_data = json.load(f)
            self.assertIn('Aspirin', saved_data)
            self.assertEqual(saved_data['Aspirin'][0]['source'], 'pubmed')

        # Nettoyage du fichier de test
        os.remove(output_file)

if __name__ == '__main__':
    unittest.main()
