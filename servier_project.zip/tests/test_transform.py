import pandas as pd
import unittest
from data_pipeline.transform import find_drug_mentions, journal_with_most_drugs, format_date, clean_text

class TestTransform(unittest.TestCase):
    def setUp(self):
        # Initialisation des données de test
        self.drugs = pd.DataFrame({'drug': ['Aspirin', 'Ibuprofen']})
        self.pubmed_data = pd.DataFrame({
            'title': ['Aspirin in pain relief', 'Ibuprofen effects'],
            'journal': ['Pain Relief Journal', 'Health Today'],
            'date': ['2023-01-01', '2023-01-02'],
            'id': [1, 2]
        })
    
    def test_find_drug_mentions(self):
        mentions = find_drug_mentions(self.pubmed_data, self.drugs, 'title', source='pubmed')
        self.assertFalse(mentions.empty)
        self.assertIn('drug', mentions.columns)
        self.assertEqual(len(mentions), 2)  # Vérifie qu'il y a exactement 2 mentions

    def test_journal_with_most_drugs(self):
        mentions_dict = {
            'Aspirin': [{'journal': 'Pain Relief Journal'}, {'journal': 'Health Today'}],
            'Ibuprofen': [{'journal': 'Health Today'}]
        }
        journal = journal_with_most_drugs(mentions_dict)
        self.assertEqual(journal, 'Health Today')

    def test_format_date(self):
        formatted_date = format_date('2023-01-01')
        self.assertEqual(formatted_date, '01/01/2023')

    def test_clean_text(self):
        clean_str = clean_text("Journal of emergency nursing\xc3\x28")
        self.assertNotIn("\\xc3", clean_str)
        self.assertEqual(clean_str, "Journal of emergency nursing")

if __name__ == '__main__':
    unittest.main()
