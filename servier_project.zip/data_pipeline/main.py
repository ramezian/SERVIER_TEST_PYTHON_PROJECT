from data_pipeline.extract import load_config, extract_csv, extract_json
from data_pipeline.transform import find_drug_mentions, journal_with_most_drugs, format_date, clean_text
from data_pipeline.load import save_json
import pandas as pd

def main():
    # Charger la configuration
    config = load_config()

    # Extraire les données
    drugs = extract_csv(config["data_paths"]["drugs_csv"])
    pubmed_csv = extract_csv(config["data_paths"]["pubmed_csv"])
    pubmed_json = extract_json(config["data_paths"]["pubmed_json"])
    clinical_trials = extract_csv(config["data_paths"]["clinical_trials_csv"])

    # Transformer les données en trouvant les mentions de médicaments avec la source correspondante
    pubmed_mentions = find_drug_mentions(pubmed_csv, drugs, 'title', source='pubmed')
    clinical_mentions = find_drug_mentions(clinical_trials, drugs, 'scientific_title', source='clinical_trials')

    # Fusionner les résultats et organiser dans un format de dictionnaire attendu
    all_mentions = pd.concat([pubmed_mentions, clinical_mentions])
    
    # Transformer en dictionnaire avec la structure {drug: [publications]}
    mentions_dict = {}
    for _, row in all_mentions.iterrows():
        drug = row['drug']
        if drug not in mentions_dict:
            mentions_dict[drug] = []

        # Détermine le titre selon la source
        title_column = 'title' if row['source'] == 'pubmed' else 'scientific_title'
        clean_title = clean_text(row[title_column])
        clean_journal = clean_text(row['journal'])  # Nettoyer le nom du journal

        # Utiliser la fonction format_date pour convertir la date
        formatted_date = format_date(row['date'])

        # Ajouter le dictionnaire de chaque mention avec le titre et le journal nettoyés
        mentions_dict[drug].append({
            "source": row['source'],  
            "publication_id": row['id'],
            "journal": clean_journal,  
            "title": clean_title,  
            "date": formatted_date  
        })

    # Charger les données (sauvegarder au format JSON)
    save_json(mentions_dict, config["output_path"])
    
    # Afficher le journal avec le plus de médicaments uniques
    print("Journal avec le plus de médicaments uniques :", journal_with_most_drugs(mentions_dict))

if __name__ == "__main__":
    main()
