import pandas as pd
import re

def find_drug_mentions(data: pd.DataFrame, drugs: pd.DataFrame, title_column: str, source: str) -> pd.DataFrame:
    """
    Identifier les mentions de médicaments dans les titres des publications, en ajoutant la source et formatant la date.

    Paramètres :
    - data : DataFrame contenant les publications.
    - drugs : DataFrame contenant les noms des médicaments.
    - title_column : Nom de la colonne contenant les titres (peut être 'title' ou 'scientific_title').
    - source : Origine des données (par exemple, 'pubmed' ou 'clinical_trials').

    Retour :
    - DataFrame des publications contenant des mentions de médicaments avec les colonnes 'drug', 'source' et la date formatée.
    """
    mentions = []
    for drug in drugs['drug']:
        # Trouver les lignes où le titre contient le nom du médicament
        matches = data[data[title_column].str.contains(drug, case=False, na=False)].copy()
        if not matches.empty:
            matches['drug'] = drug  # Ajoute explicitement la colonne 'drug' au DataFrame
            matches['source'] = source  # Ajoute la colonne 'source' au DataFrame
            matches['date'] = matches['date'].apply(format_date)  # Appliquer le format de date
            matches['journal'] = matches['journal'].apply(clean_text)  # Nettoyer le nom du journal
            mentions.append(matches)
    return pd.concat(mentions) if mentions else pd.DataFrame()

def format_date(date_str: str) -> str:
    """
    Formater une date en chaîne de caractères au format DD/MM/YYYY.

    Paramètre :
    - date_str : La date sous forme de chaîne ou d'objet date.

    Retour :
    - Chaîne de caractères représentant la date au format DD/MM/YYYY.
    """
    return pd.to_datetime(date_str, dayfirst=True).strftime('%d/%m/%Y')



def clean_text(text: str) -> str:
    """
    Nettoyer le texte en supprimant les caractères non désirés et les séquences de codage spéciales.

    Paramètre :
    - text : Chaîne de caractères à nettoyer.

    Retour :
    - Chaîne de caractères nettoyée.
    """
    if isinstance(text, str):
        # Enlève les caractères non ASCII ou non imprimables et les caractères spéciaux comme les parenthèses
        text = re.sub(r'[^\x20-\x7E]+', '', text)  # Garde uniquement les caractères ASCII imprimables
        text = re.sub(r'[\\x[0-9A-Fa-f]{2}', '', text)  # Enlève les séquences de type "xc3x28"
        text = re.sub(r'[\(\)]', '', text)  # Enlève les parenthèses
    return text.strip()

def journal_with_most_drugs(data: dict) -> str:
    """
    Identifier le journal qui mentionne le plus de médicaments différents.

    Paramètre :
    - data : Dictionnaire des données JSON produites par la pipeline.

    Retour :
    - Nom du journal avec le plus de mentions de médicaments uniques.
    """
    journal_count = {}
    for drug, publications in data.items():
        for publication in publications:
            journal = publication['journal']
            if journal not in journal_count:
                journal_count[journal] = set()
            journal_count[journal].add(drug)
    
    # Retourner le journal avec le plus de médicaments uniques mentionnés
    return max(journal_count, key=lambda k: len(journal_count[k]))
