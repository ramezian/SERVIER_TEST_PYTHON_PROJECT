import os
import json
import pandas as pd

def convert_timestamps(obj):
    """
    Convertir les objets Timestamp en chaînes de caractères pour les enregistrer au format JSON.

    Paramètre :
    - obj : Objet à convertir.

    Retour :
    - Chaîne formatée si obj est un Timestamp.
    """
    if isinstance(obj, pd.Timestamp):
        return obj.strftime('%Y-%m-%d')  
    raise TypeError(f"Type {type(obj)} non sérialisable")

def save_json(data: dict, output_file: str):
    """
    Enregistrer les données transformées au format JSON.

    Paramètres :
    - data : Dictionnaire de données à sauvegarder.
    - output_file : Chemin du fichier de sortie.
    """
    # Créer le dossier s'il n'existe pas
    output_dir = os.path.dirname(output_file)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Sauvegarder les données au format JSON sans échappement des caractères spéciaux
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, default=convert_timestamps, ensure_ascii=False)
