# Data Pipeline Project

Ce projet est une data pipeline en Python qui identifie les mentions de médicaments dans diverses publications et génère un fichier JSON en sortie.

## Installation

```bash
pip install -r requirements.txt

